package com.banana.bananamint.persistence;

import static org.junit.jupiter.api.Assertions.*;
import com.banana.bananamint.domain.Account;
import com.banana.bananamint.domain.Customer;
import com.banana.bananamint.domain.Expense;
import com.banana.bananamint.domain.Income;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@DataJpaTest()
@ComponentScan(basePackages = {"com.banana.bananamint.persistence"})
@AutoConfigureTestEntityManager
class ExpenseJPARepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired

    private ExpenseJPARepository jpaRepo;

    @Test
    void given_an_expense_When_save_thenOK() {
        // given
        Customer customer = new Customer(1L);
        Account incomeAccount = new Account(1L);
        Expense newExpense = new Expense(null,customer,2000,LocalDate.now(),incomeAccount,"Recibo luz");
        // when
        newExpense= jpaRepo.save(newExpense);
        System.out.println("newExpense:" + newExpense);

        customer = entityManager.find(Customer.class, 1L);
        System.out.println("customer:" + customer);

        // then
        assertThat(newExpense).isNotNull();
        assertThat(newExpense.getId()).isGreaterThan(0);
    }
}