package com.banana.bananamint.services;

import com.banana.bananamint.domain.*;
import com.banana.bananamint.exception.AccountException;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.time.LocalDate;


import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest

class JPAExpenseServiceTest {

    private static final Logger logger = LoggerFactory.getLogger(JPAExpenseService.class);

    @Autowired
    private JPAExpenseService jpaService;
    @Test
    void given_an_expense_When_save_thenOK() throws AccountException {
        // given
        Customer customer = new Customer(1L);
        Account expenseAccount =  new Account(1L);
        Expense newExpense = new Expense(null,customer,2000,LocalDate.now(),expenseAccount,"Recibo de la luz");

        // when
        jpaService.addExpense(1L,1L, newExpense);
        System.out.println(newExpense);

        // then
        assertThat(newExpense).isNotNull();
        assertThat(newExpense.getId()).isGreaterThan(0);
    }


    @Test
    void showAllIncomes() {
    }

    @Test
    void addIncome() {
    }

    @Test
    void showAllExpenses() {
    }

    @Test
    void addExpense() {
    }

    @Test
    void showAllExpensesByDateRange() {
    }

    @Test
    void getFinancialPerspective() {
    }
}