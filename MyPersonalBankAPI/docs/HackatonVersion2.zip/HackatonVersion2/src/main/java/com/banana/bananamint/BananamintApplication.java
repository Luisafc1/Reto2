package com.banana.bananamint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BananamintApplication {

	public static void main(String[] args) {
		SpringApplication.run(BananamintApplication.class, args);
	}

}
