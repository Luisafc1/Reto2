package com.banana.bananamint.services;

import com.banana.bananamint.domain.Account;
import com.banana.bananamint.domain.Customer;
import com.banana.bananamint.domain.Expense;
import com.banana.bananamint.domain.Income;
import com.banana.bananamint.exception.IncomeExpenseException;
import com.banana.bananamint.payload.IncomeExpenseComparison;
import com.banana.bananamint.persistence.AccountJPARepository;
import com.banana.bananamint.persistence.ExpenseJPARepository;
import com.banana.bananamint.persistence.GoalJPARepository;
import com.banana.bananamint.persistence.IncomeJPARepository;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.util.List;


@Service
public class JPAExpenseService implements IncomeExpenseService{
    private Logger logger = LoggerFactory.getLogger(IncomeExpenseService.class);

    @Autowired
    private EntityManager entityManager;
    @Autowired
    private AccountJPARepository accountRepo;

    @Autowired
    private ExpenseJPARepository expenseRepository;
    @Override
    public List<Income> showAllIncomes(Long idCustomer) throws IncomeExpenseException {
        return null;
    }

    @Override
    public Income addIncome(Long idCustomer, Long idAccount, Income income) throws IncomeExpenseException {
         return null;
    }

    @Override
    public List<Income> showAllExpenses(Long idCustomer) throws IncomeExpenseException {
        return null;
    }

    @Override
    public Expense addExpense(Long idCustomer, Long idAccount, Expense expense) throws IncomeExpenseException {
        Customer customer = entityManager.find(Customer.class,idCustomer);
        Account expenseAccount = entityManager.find(Account.class,idAccount);
        expense.setMoneyFrom(expenseAccount);
        expense.setDueDate(LocalDate.now());
        expense.setUser(customer);
        return expenseRepository.save(expense);
    }


    @Override
    public List<Income> showAllExpensesByDateRange(Long idCustomer, LocalDate initDate, LocalDate finalDate) throws IncomeExpenseException {
        return null;
    }

    @Override
    public List<IncomeExpenseComparison> getFinancialPerspective(Long idCustomer, LocalDate initDate, LocalDate finalDate) throws IncomeExpenseException {
        return null;
    }
}
